sap.ui.define([
	"zsample1/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
